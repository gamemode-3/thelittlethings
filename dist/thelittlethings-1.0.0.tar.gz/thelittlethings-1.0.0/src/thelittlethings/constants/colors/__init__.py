"""
a collection of colors represented as tuples of integers
"""

from ._colors import *