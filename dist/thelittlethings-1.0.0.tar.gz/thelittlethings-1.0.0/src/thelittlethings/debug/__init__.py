from ._log import Log
from ._timer import Timer
from ._coloring import translate_color_codes