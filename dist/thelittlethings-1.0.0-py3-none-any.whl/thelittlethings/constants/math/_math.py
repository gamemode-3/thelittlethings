from math import pi, inf, nan

eulers = 2.7182818284590452353602874713527
sqrt_1 = 1.0j